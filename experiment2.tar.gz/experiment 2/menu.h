/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  wenyang                                                              */
/*  STUDENT NUMBER        :  JG14225068                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/10                                                           */
/*  DESCRIPTION           :  interface of Menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by wenyang, 2014/09/23
 *
*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"linktable.h"

#define CMD_MAX_LEN 128
#define DESC_MAX_LEN 128

typedef struct DataNode 
{
    tLinkTableNode* pNext;
    char cmd[CMD_MAX_LEN];
    char desc[DESC_MAX_LEN];
    int    (*handler)();  
}tDataNode;

tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd);

int ShowAllCmd(tLinkTable * pLinkTable);

int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n);

int RunMenu(tLinkTable * pLinkTable);

int HandleMenu(tDataNode* pDataNode, tLinkTable* pLinkTable);

int Add(tLinkTable* pLinkTable);

int Delete(tLinkTable* pLinkTable);

int Help(tLinkTable* pLinkTable);

int Quit(tLinkTable* pLinkTable);

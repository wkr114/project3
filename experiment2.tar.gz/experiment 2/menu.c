/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  wenyang                                                              */
/*  STUDENT NUMBER        :  JG14225068                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/10                                                           */
/*  DESCRIPTION           :  interface of Menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by wenyang, 2014/09/23
 *
 */


#include"menu.h"



tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd)
{
    if( pLinkTable == NULL|| cmd == NULL)
    {
        return NULL;
    }
    tDataNode * pDataNode = (tDataNode*)GetLinkTableHead(pLinkTable);
    while(pDataNode != NULL)
    {
        if(!strcmp(cmd, pDataNode->cmd))
        {
            return pDataNode;                            
        }
        pDataNode = (tDataNode*)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pDataNode);
    }
    return NULL;
}

int ShowAllCmd(tLinkTable * pLinkTable)
{
    printf("Menu List :\n");
    tDataNode * pDataNode = (tDataNode*)GetLinkTableHead(pLinkTable);
    while(pDataNode != NULL)
    {
        printf("%s  ",pDataNode->cmd);
        pDataNode = (tDataNode*)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pDataNode);
    }
    printf("\n");
    return 0;
}


int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n)
{
    int i;
    for( i = 0; i < n; i++)
    {
        AddLinkTableNode(pLinkTable,(tLinkTableNode *)&data[i]);
    }
    return 0;
}

int RunMenu(tLinkTable * pLinkTable)
{ 
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tDataNode* p = FindCmd( pLinkTable, cmd);   
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);   
        HandleMenu( p, pLinkTable);
    } 
    return 0;
}

int HandleMenu(tDataNode* pDataNode, tLinkTable* pLinkTable)
{
    if( pDataNode->handler != NULL)
    {
        pDataNode->handler(pLinkTable);
    }
    return 0;  
}

int Help(tLinkTable* pLinkTable)
{
    ShowAllCmd(pLinkTable);
    return 0;
}


int Add(tLinkTable* pLinkTable)
{
    char cmd[CMD_MAX_LEN];
    char desc[DESC_MAX_LEN];
    printf( "Input a new cmd> ");
    scanf( "%s", cmd);
    tDataNode* p = FindCmd( pLinkTable, cmd);
    if(p != NULL)
    {
        printf("This cmd has existed!\n");
        return 1;
    }
    printf( "Input a new desc> ");
    scanf( "%s", desc);    
    tDataNode* data = (tDataNode *)malloc(sizeof(tDataNode));
    data->pNext = NULL;
    strcpy( data->cmd, cmd);
    strcpy( data->desc, desc);
    data->handler = NULL;   
    CreatMenu(pLinkTable, data, 1);
    printf("Add succussfully!\n");
    return 0;
}

int Delete(tLinkTable* pLinkTable)
{
    char cmd[CMD_MAX_LEN];
    printf( "Input a deleted cmd> ");
    scanf("%s", cmd);
    tDataNode* p = FindCmd( pLinkTable, cmd);
    if(p == NULL)
    {
        printf("This is a wrong cmd!\n");
        return 1;
    }
    DelLinkTableNode( pLinkTable, (tLinkTableNode *)p);
    printf("Delete succussfully!\n");
    return 0;
}

int Quit(tLinkTable* pLinkTable)
{
    exit(0);
    return 0;
}

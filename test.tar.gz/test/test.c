/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  wangkairui                                                           */
/*  STUDENT NUMBER        :  SA14226241                                                           */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  test of menu                                                         */
/**************************************************************************************************/

#include<stdio.h>
#include"menu.h"

#define debug 

int results[9] = {1};
char * info[9] =
{
    "TC1 FindCmd",
    "TC2 ShowAllCmd",
    "TC3 CreatMenu",
    "TC4 RunMenu",
    "TC5 HandleMenu",
    "TC6 Help",
    "TC7 Add",
    "TC8 Delete",
    "TC9 Quit"
};

int main()
{
    int i;
    int ret;
    tLinkTable * head = NULL;
    char * cmd = NULL;
    tDataNode * p = FindCmd( head, cmd);
    if(p == (tDataNode *)FAILURE )  
    {
        debug("TC1 fail!\n");
        results[0] = 1; 
    }
    ret = ShowAllCmd(head);
    if( ret == FAILURE )
    {
        debug("TC2 fail!\n");
        results[1] = 1;
    }
    tDataNode * data = NULL;
    ret = CreatMenu(head,data,1);
    if( ret == FAILURE )
    {
        debug("TC3 fail!\n");
        results[2] = 1;
    }
    ret = RunMenu(head);
    if( ret == FAILURE )
    {
        debug("TC4 fail!\n");
        results[3] = 1;
    }
    ret = HandleMenu(data,head);
    if( ret == FAILURE )
    {
        debug("TC5 fail!\n");
        results[4] = 1;
    }
    ret = Help(head);
    if( ret == FAILURE )
    {
        debug("TC6 fail!\n");
        results[5] = 1;
    }
    ret = Add(head);
    if( ret == FAILURE )
    {
        debug("TC7 fail!\n");
        results[6] = 1;
    }
    ret = Delete(head);
    if( ret == FAILURE )
    {
        debug("TC8 fail!\n");
        results[7] = 1;
    }
    ret = Quit(head);
    if( ret == FAILURE )
    {
        debug("TC9 fail!\n");
        results[8] = 1;
    }
    
    printf("test report:\n");
    for( i=0 ; i<9; i++)
    {
        if( results[i] == 1)
        {
            printf("Testcase Number%d Failure- %s\n",i,info[i]);
        }
    }
}

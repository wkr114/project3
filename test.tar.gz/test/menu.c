/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  wangkairui                                                           */
/*  STUDENT NUMBER        :  SA14226241                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/10                                                           */
/*  DESCRIPTION           :  test stub of menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by wangkairui, 2014/09/29
 *
*/

#include"menu.h"

/*
 * Find the Cmd
 */

tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd)
{
    if( pLinkTable == NULL|| cmd == NULL )
    {
        return (tDataNode *)FAILURE;
    }
    return (tDataNode *)SUCCESS;
}
/*
 * Print All Cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Creat a Menu
 */
int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n)
{
    if( pLinkTable == NULL|| data == NULL || n < 0)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Run the Menu
 */
int RunMenu(tLinkTable * pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;    
}
/*
 * Run Handler function in Menu
 */
int HandleMenu(tDataNode* pDataNode, tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL|| pDataNode == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Print All Cmd
 */
int Help(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Add a Cmd to Menu
 */
int Add(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Delete a Cmd from Menu
 */
int Delete(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}
/*
 * Quit Menu
 */
int Quit(tLinkTable* pLinkTable)
{
    if( pLinkTable == NULL )
    {
        return FAILURE;
    }
    return SUCCESS;
}


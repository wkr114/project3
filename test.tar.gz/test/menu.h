/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  wangkairui                                                           */
/*  STUDENT NUMBER        :  SA14226241                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/10                                                           */
/*  DESCRIPTION           :  interface of Menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by wangkairui, 2014/09/23
 *
*/

#include<stdlib.h>

#define SUCCESS 1
#define FAILURE -1

typedef struct LinkTable 
{

}tLinkTable;
/*
 * Data Node Type
 */
typedef struct DataNode 
{

}tDataNode;
/*
 * Find the Cmd
 */
tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd);
/*
 * Print All Cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable);
/*
 * Creat a Menu
 */
int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n);
/*
 * Run the Menu
 */
int RunMenu(tLinkTable * pLinkTable);
/*
 * Run Handler function in Menu
 */
int HandleMenu(tDataNode* pDataNode, tLinkTable* pLinkTable);
/*
 * Print All Cmd
 */
int Help(tLinkTable* pLinkTable);
/*
 * Add a Cmd to Menu
 */
int Add(tLinkTable* pLinkTable);
/*
 * Delete a Cmd from Menu
 */
int Delete(tLinkTable* pLinkTable);
/*
 * Quit Menu
 */
int Quit(tLinkTable* pLinkTable);

/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  wangkairui                                                           */
/*  STUDENT NUMBER        :  SA14226241                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/10                                                           */
/*  DESCRIPTION           :  interface of Menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by wangkairui, 2014/09/23
 *
 */

#include"menu.h"

/*
 * Find the Cmd
 */
tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd)
{
    if( pLinkTable == NULL|| cmd == NULL)
    {
        return NULL;
    }
    tDataNode * pDataNode = (tDataNode*)GetLinkTableHead(pLinkTable);
    while(pDataNode != NULL)
    {
        if(!strcmp(cmd, pDataNode->cmd))
        {
            return pDataNode;                            
        }
        pDataNode = (tDataNode*)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pDataNode);
    }
    return NULL;
}
/*
 * Print All Cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable)
{
    printf("Menu List :\n");
    tDataNode * pDataNode = (tDataNode*)GetLinkTableHead(pLinkTable);
    while(pDataNode != NULL)
    {
        printf("%s  ",pDataNode->cmd);
        pDataNode = (tDataNode*)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pDataNode);
    }
    printf("\n");
    return 0;
}
/*
 * Creat a Menu
 */
int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n)
{
    int i;
    for( i = 0; i < n; i++)
    {
        AddLinkTableNode(pLinkTable,(tLinkTableNode *)&data[i]);
    }
    return 0;
}
/*
 * Run the Menu
 */
int RunMenu(tLinkTable * pLinkTable)
{ 
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tDataNode* p = FindCmd( pLinkTable, cmd);   
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);   
        HandleMenu( p, pLinkTable);
    } 
    return 0;
}
/*
 * Run Handler function in Menu
 */
int HandleMenu(tDataNode* pDataNode, tLinkTable* pLinkTable)
{
    if( pDataNode->handler != NULL)
    {
        pDataNode->handler(pLinkTable);
    }
    return 0;  
}
/*
 * Print All Cmd
 */
int Help(tLinkTable* pLinkTable)
{
    ShowAllCmd(pLinkTable);
    return 0;
}
/*
 * Add a Cmd to Menu
 */
int Add(tLinkTable* pLinkTable)
{
    char cmd[CMD_MAX_LEN];
    char desc[DESC_MAX_LEN];
    printf( "Input a new cmd> ");
    scanf( "%s", cmd);
    tDataNode* p = FindCmd( pLinkTable, cmd);
    if(p != NULL)
    {
        printf("This cmd has existed!\n");
        return 1;
    }
    printf( "Input a new desc> ");
    scanf( "%s", desc);    
    tDataNode* data = (tDataNode *)malloc(sizeof(tDataNode));
    data->pNext = NULL;
    strcpy( data->cmd, cmd);
    strcpy( data->desc, desc);
    data->handler = NULL;   
    CreatMenu(pLinkTable, data, 1);
    printf("Add succussfully!\n");
    return 0;
}
/*
 * Delete a Cmd from Menu
 */
int Delete(tLinkTable* pLinkTable)
{
    char cmd[CMD_MAX_LEN];
    printf( "Input a deleted cmd> ");
    scanf("%s", cmd);
    tDataNode* p = FindCmd( pLinkTable, cmd);
    if(p == NULL)
    {
        printf("This is a wrong cmd!\n");
        return 1;
    }
    DelLinkTableNode( pLinkTable, (tLinkTableNode *)p);
    printf("Delete succussfully!\n");
    return 0;
}
/*
 * Print All Cmd
 */
int Quit(tLinkTable* pLinkTable)
{
    exit(0);
    return 0;
}

/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  wangkairui                                                           */
/*  STUDENT NUMBER        :  SA14226241                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  interface of Menu                                                    */
/**************************************************************************************************/

#include"menu.h"
#include"linktable.h"
/*
 * Input data in Menu
 */
static tDataNode data[] = 
{
    {NULL, "help", "this is help cmd!", Help},
    {NULL, "version", "menu program v1.0", NULL},
    {NULL, "modtime", "2014/9/23", NULL},
    {NULL, "system", "ubuntu", NULL},
    {NULL, "add", "a cmd", Add},
    {NULL, "delete", "a cmd", Delete},
    {NULL, "quit", "successfully", Quit}
};
/*
 * Test fuction
 */
void main()
{
    tLinkTable* head = CreateLinkTable();
    CreatMenu(head, data, 7);
    RunMenu(head);
}


